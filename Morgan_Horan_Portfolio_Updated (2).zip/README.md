# Morgan Horan — Personal Portfolio

A responsive personal portfolio website built with HTML, CSS, and JavaScript.

## Publish on GitHub Pages

1. Sign in to [GitHub](https://github.com/) and create a **public** repository named `portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root, then commit the files.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then click **Save**.
5. Wait for GitHub Pages to deploy. Your site should appear at `https://YOUR-USERNAME.github.io/portfolio/`.
6. Submit both `https://github.com/YOUR-USERNAME/portfolio` and your live GitHub Pages URL.

## Before publishing

- Replace the generic LinkedIn homepage link in `index.html` with your actual LinkedIn profile URL, or remove the button until you have one.
- Confirm that the project descriptions accurately represent your work.
- If you have project repositories, presentations, or demos that you can share publicly, add working links to the project cards. Do not publish confidential work.
- Review the design on a phone and computer.

## PGIM Certificate
The PGIM project links to `pgim-credit-certificate.pdf`. Keep this file in the same folder as `index.html` when publishing to GitHub Pages.
